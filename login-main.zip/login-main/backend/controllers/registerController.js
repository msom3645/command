const User = require('../models/userModel')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const mailer = require('../nodemailer')
exports.register = async (req, res)=>{
    const {name, email, password} = req.body
    try{
            const userExists = await User.findOne({email})
            if(userExists){
                res.status(200).send({message:'User Exists'})
            }else{
                const hashPassword = await bcrypt.hash(password, 10)
                const token = jwt.sign({name,email, password:hashPassword}, process.env.SECRET, {expiresIn:'30d'})
                mailer({
                    to: email,
                    subject:'hello',
                    html: `http://localhost:3000/verify/${email}/${token}`
                })
                res.status(200).send({message:'Confirm Registration by Email'})
            }
                
    }catch(error){
        res.status(400).send({
            message:error
        })
    }

    }

exports.verifyEmail = async(req, res) => {
    const {email,token} = req.body
    try{
        const userExists = await User.findOne({email})
        if(userExists){
            res.status(200).send({userExists:true, message:'User Already Registered'})
        }else{
        const decoded = jwt.verify(token, process.env.SECRET)
        const user = await User.create({
                name:decoded.name,
                email:decoded.email,
                password:decoded.password
            })
            res.status(200).send({message:'User Successfuly Registered!',user, token})
        }
        }catch(error){
        res.status(400).send({message:error})
    }
}

exports.login = async(req, res) => {
    const {password, email} = req.body
    try{
        const user = await User.findOne({email})
        if(user && bcrypt.compareSync(password, user.password)){
            const token = jwt.sign({user}, process.env.SECRET, {expiresIn:'30d'})
            res.status(200).send({_id:user._id, name:user.name, email:user.email, token})
        }else{
            res.status(401).send({message:'Invalid Email or Password'})
        }
    }catch(error){
        res.status(400).send({message:error})
    }
}

exports.resetController = async(req, res) => {
    const email = req.body.email
    try{
        const user = await User.findOne({email})
        if(user){
            const token = jwt.sign({email}, process.env.SECRET,{expiresIn:'2h'})
            user.resetToken.token = token
            user.resetToken.date = Date.now()
            await user.save()
            mailer({
                to:email,
                subject: 'Password Reset',
                html:`http://localhost:3000/reset-password/${email}/${token}`
            })
            res.status(200).send({message:'Please check your email inbox for a link to complete the reset.'})
        }else{
            res.status(400).send({message:'User not Found'})
        }
    }catch(error){
        res.status(400).send({message:error})
    }
}

exports.newpasswordController = async(req, res) => {
    const {token, email, password} = req.body    
    try{
        const user = await User.findOne({email}) 
        if(token !== user.resetToken.token || user.resetToken.date.getTime() + 120* 60 * 1000< Date.now() ){
            res.status(400).send({message:'Token Expired'})
        }else{
            const hashPassword = await bcrypt.hash(password, 10)
            user.password = hashPassword
            user.save()
            res.status(200).send({message:'Passwor Updated!'})
        }
    }catch(error){
        res.status(400).send({message:error})
    }
}