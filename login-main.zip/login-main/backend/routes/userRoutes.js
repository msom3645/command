const router = require('express').Router()
const {register, verifyEmail, login, resetController, newpasswordController} = require('../controllers/registerController')
router.route('/register').post(register)
router.route('/verify').post(verifyEmail)
router.route('/login').post(login)
router.route('/reset-password').post(resetController)
router.route('/new-password').post(newpasswordController)

module.exports = router