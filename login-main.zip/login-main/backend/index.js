const express = require('express')
const mongoose = require('mongoose')
const cookieParser = require('cookie-parser')
const cors = require('cors')
require('dotenv').config()
const app = express()
const fileUpload = require('express-fileupload')
app.use(cookieParser())
app.use(express.json())
app.use(express.urlencoded({extended:true}))
app.use(cors())
app.use(fileUpload(
    {useTempFiles:true}
))
const userRouter = require('./routes/userRoutes')
mongoose.connect(process.env.MONGO_URI,                                       
    { useUnifiedTopology: true,
        useNewUrlParser: true 
    } )
mongoose.connection.on('connected', ()=>{
    console.log('Connected to mongo!!')
}) 
mongoose.connection.on('error', (err)=>{
    console.log('err connecting', err)
})

app.use('/api/users',userRouter)


app.listen(5000, console.log('server running on port 5000'))

