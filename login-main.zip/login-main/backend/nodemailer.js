const nodemailer = require('nodemailer')
const transporter = nodemailer.createTransport({
    host:'smtp.yandex.ru',
    port:465,
    secure:true,
    auth:{
        user:'mso2000@yandex.ru',
        pass:'111333Aa+'
    }
}, {from:'Mailer Test<mso2000@yandex.ru>'})

const mailer = message => {
    transporter.sendMail(message, (err, info)=>{
        if(err){
            return console.log(err)
        }
        console.log('Email sent', info)
    })
}
module.exports = mailer