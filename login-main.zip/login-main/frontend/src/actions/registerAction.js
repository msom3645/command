import axios from 'axios'
export const registerAction = (name, email, password) => async(dispatch)=>{
    dispatch({type:'USER_REGISTER_REQUEST'})
    try{
        const {data} = await axios.post('http://localhost:5000/api/users/register', {name, email, password})
        dispatch({
            type:'USER_REGISTER_EMAIL_SUCCESS', payload:data
        })
        localStorage.setItem('user', JSON.stringify(data))
    }catch(error){
        dispatch({
            type:'USER_REGISTER_FAIL',
            payload:error.response && error.response.data.message?
            error.response.data.message: error.message
        })
    }
}

export const loginAction = (email, password) => async(dispatch) => {
    dispatch({type:'USER_LOGIN_REQUEST'})
    try{
        const {data} = await axios.post('http://localhost:5000/api/users/login',{email,password})
        dispatch({type:'USER_LOGIN_SUCCESS', payload:data})
        localStorage.setItem('user', JSON.stringify(data))
        document.location.href = '/'
    }catch(error){
        dispatch({type:'USER_LOGIN_FAIL', payload:error.response && error.response.data.message?
        error.response.data.message:error.message
    })
    }
}

export const signout = () => (dispatch) => {
    localStorage.removeItem('user')
    dispatch({type:'USER_LOGOUT'})
    document.location.href ='/register'
}