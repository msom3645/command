import {createStore, combineReducers, applyMiddleware, compose} from 'redux'                                //var 2 store
import thunk from 'redux-thunk'
import {registerReducer, loginReducer} from './reducers/userReducer'
const reducer = combineReducers({
    registerReducer,
    loginReducer
})
const initialState = {
    registerReducer: { user: localStorage.getItem('user')? JSON.parse(localStorage.getItem('user')): null}
}
const composeEnhancer = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const store = createStore(
  reducer,
  initialState,
  composeEnhancer(applyMiddleware(thunk))
);
export default store
