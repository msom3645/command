import React from 'react'
import './index.css'
import {BrowserRouter, Route} from 'react-router-dom'
import RegisterScreen from './screens/RegisterScreen'
import VerifyEmailScreen from './screens/VerifyEmailScreen'
import HomeScreen from './screens/HomeScreen'
import LoginScreen from './screens/LoginScreen'
import ResetEmail from './screens/ResetEmail'
import NewPassword from './screens/NewPassword'
function App() {
  return (
   <BrowserRouter>
   <Route path='/' component={HomeScreen} exact/>
    <Route path='/register' component={RegisterScreen}/>
    <Route path='/verify/:email/:id' component={VerifyEmailScreen}/>
    <Route path='/login' component={LoginScreen} />
    <Route path='/reset-email' component={ResetEmail} />
    <Route path='/reset-password/:email/:token' component={NewPassword} />
</BrowserRouter>
  )
}

export default App;
