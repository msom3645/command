import React, {useEffect, useState} from 'react'
import axios from 'axios'
const NewPassword = (props) => {
    const [password, setPassword] = useState('')
    const [password2, setPassword2] = useState('')
    const formHandler = async (e) => {
        e.preventDefault()
        const {email, token} = props.match.params
        if(password !== password2){
            alert('passwords do not match!')
        }
        try{
            const {data} = await axios.post('http://localhost:5000/api/users/new-password', {token, email, password})
            document.location.href='/login'
        console.log(data)
        }catch(error){
            console.log(error.response)
        }
    }
    return (
        <div>
              <form onSubmit={formHandler}>
                <input type='password' placeholder='New Password' autoFocus onChange={e=>setPassword(e.target.value)}/>
                <input type='password' placeholder='Confirm Password' onChange={e=>setPassword2(e.target.value)}/>
                <button>Send</button>
              </form>
        </div>
    )
}

export default NewPassword
