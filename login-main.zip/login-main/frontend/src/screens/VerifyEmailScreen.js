import React,{useState, useEffect} from 'react'
import axios from 'axios'

const VerifyEmailScreen = (props) => {
    const token = props.match.params.id
    const email = props.match.params.email
    const [message, setMessage] = useState(null)
   useEffect(()=>{
    const fetch = async() => {
        try{
            const {data} = await axios.post('http://localhost:5000/api/users/verify',{email,token})
            if(data.userExists){
                setMessage(data.message)
                setTimeout(()=>{
                    props.history.push('/')
                },2000)
            }else{
                setMessage(data.message)
                const user = {...data.user, token:data.token}
                localStorage.setItem('user', JSON.stringify(user))
                props.history.push('/')
            }          
        }catch(error){
            setMessage(error)
        }
    }
    fetch()
   },[])
    return (
        <div>
            <h2>{message}</h2>
        </div>
    )
}

export default VerifyEmailScreen
