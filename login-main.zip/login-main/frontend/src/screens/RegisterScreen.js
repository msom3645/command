import React,{useState} from 'react'
import {useSelector, useDispatch} from 'react-redux'
import {registerAction} from '../actions/registerAction'
const RegisterScreen = () => {
    const dispatch = useDispatch()
    const [name, setName] = useState(null)
    const [email, setEmail] = useState(null)
    const [password, setPassword] = useState(null)
    const [password2, setPassword2] = useState(null)
    const formHandler = (e) => {
        e.preventDefault()
        if(password!==password2){
            alert('passwords are not match')
        }else{
            dispatch(registerAction(name, email, password))
        }
    }
    
    return (
        <form onSubmit={formHandler} >
            <input autoComplete='on'minLength='1' onChange={e=>setName(e.target.value)} type='text' placeholder='name'  autoFocus required title='Enter your name here'/>
            <input onChange={e=>setEmail(e.target.value)} type='email' placeholder='email' autoComplete='on' required />
            <input onChange={e=>setPassword(e.target.value)} type='password' placeholder='password' required minLength='6'/>
            <input onChange={e=>setPassword2(e.target.value)} type='password' placeholder='password' required minLength='6'/>
            <button>Register</button>
        </form>
    )
}

export default RegisterScreen
