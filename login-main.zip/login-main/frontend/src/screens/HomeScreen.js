import React, {useState, useEffect} from 'react'
import { useDispatch, useSelector } from 'react-redux'
import {signout} from '../actions/registerAction'
const HomeScreen = () => {
    const [name, setName] = useState('')
    const {user} = useSelector(state=>state.registerReducer)
    const dispatch = useDispatch()
    const logout = ()=>{
        dispatch(signout())
    }
    useEffect(()=> {
        setName(user.name)
        setTimeout(()=>{
            setName('')
        },2000)

    },[])
    return (
        <div>
            {name? <h1>{name}</h1>:''}
            <button onClick={logout}>Log Out</button>
        </div>
    )
}

export default HomeScreen
