import axios from 'axios'
import React, {useState} from 'react'

const ResetEmail = () => {
    const [email, setEmail] = useState('')
    const formHandler = async(e) => {
        e.preventDefault()
        try{
            const data = await axios.post('http://localhost:5000/api/users/reset-password', {email})
        console.log(data)
        }catch(error){
            console.log(error.response.data.message)
        }
    }
    return (
        <form onSubmit={formHandler} >
            <input type='email' onChange={e=>setEmail(e.target.value)} required autoFocus placeholder='email'/>
            <button>Send Password</button>
        </form>
    )
}

export default ResetEmail
