import React,{useState, useEffect} from 'react'
import {useDispatch, useSelector} from 'react-redux'
import {loginAction} from '../actions/registerAction'
const LoginScreen = () => {
    const [password, setPassword] = useState(null)
    const [email, setEmail] = useState(null)
    const dispatch = useDispatch()
    const formHandler = async(e) => {
        e.preventDefault()
        dispatch(loginAction(email, password))
    }
    return (
        <form onSubmit={formHandler} >
            <input autoComplete='on' onChange={e=>setEmail(e.target.value)} type='email' placeholder='email..' required/>
            <input autoComplete='on' type='password' onChange={e=>setPassword(e.target.value)} autoFocus placeholder='password...' required/>
            <button>Login</button>
        </form>
    )
}

export default LoginScreen
